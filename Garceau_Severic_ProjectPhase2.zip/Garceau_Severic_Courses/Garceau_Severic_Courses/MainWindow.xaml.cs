﻿/*
 * Jeremy Severic and Zachary Garceau
 * CSC 460 - Rapid Application Development
 * Group Project Phase 2
 */


using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace Garceau_Severic_Courses
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            PopulateDG();
        }

        // Event for Course Details
        private void dgMain_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            Courses course = dgMain.SelectedItem as Courses;
            CourseDetails cd = new CourseDetails();
            cd.Show();

            var ctx = new CourseContext();
            var ins = ctx.Instructor.FirstOrDefault(x => x.Id == course.Instructor_Id);


            cd.txtId.Text = course.Id.ToString();
            cd.txtDept.Text = course.Dept;
            cd.txtNum.Text = course.Number.ToString();
            cd.txtName.Text = course.Name;
            cd.txtDescription.Text = course.Description;
            cd.txtPreReq.Text = course.PreReq;
            cd.txtIns.Text = ins.ToString();
            cd.txtStatus.Text = course.Status;
            cd.txtSize.Text = course.ClassSize.ToString();
            cd.txtEnrolled.Text = course.Enrolled.ToString();
            cd.txtSem.Text = course.Semester;
            cd.txtYear.Text = course.Year.ToString();
            cd.txtSection.Text = course.Section;
            cd.txtHours.Text = course.Hours.ToString();
            cd.txtDays.Text = course.Days;
            cd.txtTime.Text = course.Time;
            cd.txtLocation.Text = course.RoomNum;
        }
        
        // Event for Adding New Class
        private void btnAddCourse_Click(object sender, RoutedEventArgs e)
        {
            AddNewCourse newCourse = new AddNewCourse();
            newCourse.Show();
            newCourse.Closed += add_course;
        }

        // Event for Adding New Instructor
        private void btnAddInstructor_Click(object sender, RoutedEventArgs e)
        {
            AddIns addInstructor = new AddIns();
            addInstructor.Show();
            addInstructor.Closed += add_instructor;
        }
       
        // Event for Modify class (double-click)
        private void dgMain_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ModifyCourse modCourse = new ModifyCourse();
            Courses course = dgMain.SelectedItem as Courses;
            var ctx = new CourseContext();
            var ins = ctx.Instructor.FirstOrDefault(x => x.Id == course.Instructor_Id);

            var correctName = ins.LastName + ", " + ins.FirstName;

            modCourse.txtId.Text = ins.Id.ToString();
            modCourse.txtDept.Text = course.Dept;
            modCourse.txtNum.Text = course.Number.ToString();
            modCourse.txtName.Text = course.Name;
            modCourse.txtDescription.Text = course.Description;
            modCourse.txtPrereq.Text = course.PreReq;
            modCourse.txtInstructor.Text = correctName;
            modCourse.txtStatus.Text = course.Status;
            modCourse.txtClassSize.Text = course.ClassSize.ToString();
            modCourse.txtEnrolled.Text = course.Enrolled.ToString();
            modCourse.txtSemester.Text = course.Semester;
            modCourse.txtYear.Text = course.Year.ToString();
            modCourse.txtSection.Text = course.Section;
            modCourse.txtHours.Text = course.Hours.ToString();
            modCourse.txtDays.Text = course.Days;
            modCourse.txtTime.Text = course.Time;
            modCourse.txtRoom.Text = course.RoomNum;

            modCourse.Show();
            modCourse.Closed += modify_course;
        }
        
        // Event for Filter Courses
        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            FilterCourses filterCourses = new FilterCourses();
            filterCourses.Show();
            filterCourses.Closed += FilterCourses_Closed;
        }
        
        // Event to refresh datagrid
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            PopulateDG();
        }

        // Function: Modifying a course
        private void modify_course(Object sender, EventArgs e)
        {
            ModifyCourse modCourse = (ModifyCourse)sender;
            Courses course = dgMain.SelectedItem as Courses;
            var ctx = new CourseContext();

            string fname = modCourse.txtInstructor.Text.Trim().Split(", ")[1];
            string lname = modCourse.txtInstructor.Text.Trim().Split(", ")[0];
            string correctName = lname + ", " + fname;
            
            int courseID = course.Id;
            int ogID = Convert.ToInt32(modCourse.txtId.Text);

            var insCheckName = ctx.Instructor.FirstOrDefault(x => x.FirstName == fname && x.LastName == lname); // Checking to see if new instructor is in Instructor database
            var insCheckID = ctx.Instructor.FirstOrDefault(x => x.Id == ogID); // Checking to see if old instructor matches new Instructor

            if (insCheckName != null && insCheckName.Id == insCheckID.Id) // If instructor is the same, update course only.
            {
                try
                {
                    var editCourse = ctx.Course.Where(x => x.Id == courseID).First();
                    editCourse.Dept = modCourse.txtDept.Text;
                    editCourse.Number = Convert.ToInt32(modCourse.txtNum.Text);
                    editCourse.Name = modCourse.txtName.Text;
                    editCourse.Description = modCourse.txtDescription.Text;
                    editCourse.PreReq = modCourse.txtPrereq.Text;
                    editCourse.Status = modCourse.txtStatus.Text;
                    editCourse.ClassSize = Convert.ToInt32(modCourse.txtClassSize.Text);
                    editCourse.Enrolled = Convert.ToInt32(modCourse.txtEnrolled.Text);
                    editCourse.Semester = modCourse.txtSemester.Text;
                    editCourse.Year = Convert.ToInt32(modCourse.txtYear.Text);
                    editCourse.Section = modCourse.txtSection.Text;
                    editCourse.Hours = Convert.ToInt32(modCourse.txtHours.Text);
                    editCourse.Days = modCourse.txtDays.Text;
                    editCourse.Time = modCourse.txtTime.Text;
                    editCourse.RoomNum = modCourse.txtRoom.Text;

                    ctx.SaveChanges();
                    PopulateDG();
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK);
                }

            }
            else if (insCheckName != null && insCheckName.Id != insCheckID.Id) // If instructor is different and exists, update instructor in course.
            {
                try
                {
                    var editCourse = ctx.Course.Where(x => x.Id == courseID).First();
                    editCourse.Dept = modCourse.txtDept.Text;
                    editCourse.Number = Convert.ToInt32(modCourse.txtNum.Text);
                    editCourse.Name = modCourse.txtName.Text;
                    editCourse.Description = modCourse.txtDescription.Text;
                    editCourse.PreReq = modCourse.txtPrereq.Text;
                    editCourse.Status = modCourse.txtStatus.Text;
                    editCourse.ClassSize = Convert.ToInt32(modCourse.txtClassSize.Text);
                    editCourse.Enrolled = Convert.ToInt32(modCourse.txtEnrolled.Text);
                    editCourse.Semester = modCourse.txtSemester.Text;
                    editCourse.Year = Convert.ToInt32(modCourse.txtYear.Text);
                    editCourse.Section = modCourse.txtSection.Text;
                    editCourse.Hours = Convert.ToInt32(modCourse.txtHours.Text);
                    editCourse.Days = modCourse.txtDays.Text;
                    editCourse.Time = modCourse.txtTime.Text;
                    editCourse.RoomNum = modCourse.txtRoom.Text;
                    editCourse.Instructor_Id = insCheckName.Id;

                    ctx.SaveChanges();
                    PopulateDG();

                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK);
                }

            }
            else // If instructor is new, add new instructor and update course.
            {
                try
                {
                    Instructors newIns = new Instructors()
                    {
                        FirstName = fname,
                        LastName = lname,
                        Courses = new List<Courses>()
                    };
                    ctx.Instructor.Add(newIns);
                    ctx.SaveChanges();

                    Debug.WriteLine(newIns.FirstName + newIns.LastName);

                    var editCourse = ctx.Course.Where(x => x.Id == courseID).First();
                    editCourse.Dept = modCourse.txtDept.Text;
                    editCourse.Number = Convert.ToInt32(modCourse.txtNum.Text);
                    editCourse.Name = modCourse.txtName.Text;
                    editCourse.Description = modCourse.txtDescription.Text;
                    editCourse.PreReq = modCourse.txtPrereq.Text;
                    editCourse.Status = modCourse.txtStatus.Text;
                    editCourse.ClassSize = Convert.ToInt32(modCourse.txtClassSize.Text);
                    editCourse.Enrolled = Convert.ToInt32(modCourse.txtEnrolled.Text);
                    editCourse.Semester = modCourse.txtSemester.Text;
                    editCourse.Year = Convert.ToInt32(modCourse.txtYear.Text);
                    editCourse.Section = modCourse.txtSection.Text;
                    editCourse.Hours = Convert.ToInt32(modCourse.txtHours.Text);
                    editCourse.Days = modCourse.txtDays.Text;
                    editCourse.Time = modCourse.txtTime.Text;
                    editCourse.RoomNum = modCourse.txtRoom.Text;
                    editCourse.Instructor_Id = newIns.Id;

                    ctx.SaveChanges();
                    PopulateDG();
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK);
                }

            }

        }

        // Function: Adding new course
        private void add_course(Object sender, EventArgs e)
        {
            AddNewCourse course = (AddNewCourse)sender;
            try
            {
                string fname = course.txtInstructor.Text.Split(", ")[1];
                string lname = course.txtInstructor.Text.Trim().Split(", ")[0];
                string fullName = fname + ", " + lname;


                var ctx = new CourseContext();
                var courseCheck = ctx.Course.FirstOrDefault(x => x.Name == course.txtName.Text);
                var insCheck = ctx.Instructor.FirstOrDefault(x => x.FirstName == fname && x.LastName == lname);

                if (insCheck != null) // If there is a match for professor
                {
                    if (courseCheck != null)
                    {
                        throw new Exception("This course already exists.");
                    }
                    else
                    {
                        Courses newCourse = new Courses()
                        {
                            Dept = course.txtDept.Text,
                            Number = Convert.ToInt32(course.txtNum.Text),
                            Name = course.txtName.Text,
                            Description = course.txtDescription.Text,
                            PreReq = course.txtPrereq.Text,
                            Instructor_Id = insCheck.Id,
                            Status = course.txtStatus.Text,
                            ClassSize = Convert.ToInt32(course.txtClassSize.Text),
                            Enrolled = Convert.ToInt32(course.txtEnrolled.Text),
                            Semester = course.txtSemester.Text,
                            Section = course.txtSection.Text,
                            Hours = Convert.ToInt32(course.txtHours.Text),
                            Year = Convert.ToInt32(course.txtYear.Text),
                            Days = course.txtDays.Text,
                            Time = course.txtTime.Text,
                            RoomNum = course.txtRoom.Text
                        };

                        ctx.Course.Add(newCourse);
                        ctx.SaveChanges();
                        PopulateDG();
                    }
                }
                else if (insCheck == null) // If there is not a match for professor
                {
                    Instructors newInstructor = new Instructors()
                    {
                        FirstName = fname,
                        LastName = lname,
                    };
                    ctx.Instructor.Add(newInstructor);
                    ctx.SaveChanges();

                    var ins = ctx.Instructor.FirstOrDefault(x => x.FirstName == fname && x.LastName == lname);
                    Courses newCourse = new Courses()
                    {
                        Dept = course.txtDept.Text,
                        Number = Convert.ToInt32(course.txtNum.Text),
                        Name = course.txtName.Text,
                        Description = course.txtDescription.Text,
                        PreReq = course.txtPrereq.Text,
                        Instructor_Id = ins.Id,
                        Status = course.txtStatus.Text,
                        ClassSize = Convert.ToInt32(course.txtClassSize.Text),
                        Enrolled = Convert.ToInt32(course.txtEnrolled.Text),
                        Semester = course.txtSemester.Text,
                        Section = course.txtSection.Text,
                        Hours = Convert.ToInt32(course.txtHours.Text),
                        Days = course.txtDays.Text,
                        Time = course.txtTime.Text,
                        RoomNum = course.txtRoom.Text
                    };

                    ctx.Course.Add(newCourse);
                    ctx.SaveChanges();
                    PopulateDG();
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK);
            }
        }

        // Function: Adding instructor to database
        private void add_instructor(Object sender, EventArgs e)
        {
            AddIns ins = (AddIns)sender;
            try
            {
                using (var ctx = new CourseContext())
                {
                    // Checks to see if the text boxes are empty
                    if (ins.txtFirstName.Text == "" || ins.txtLastName.Text == "")
                    {
                        throw new Exception("Please enter a first and last name.");
                    }
                    else
                    {
                        // Checks to see if instructor already exists
                        var insCheck = ctx.Instructor.FirstOrDefault(x => x.FirstName == ins.txtFirstName.Text && x.LastName == ins.txtLastName.Text);
                        if (insCheck != null)
                        {
                            throw new Exception("Instructor already exists.");
                        }
                        else
                        {
                            Instructors newInstructor = new Instructors()
                            {
                                FirstName = ins.txtFirstName.Text,
                                LastName = ins.txtLastName.Text,
                                Courses = new List<Courses>()
                            };
                            ctx.Instructor.Add(newInstructor);
                            ctx.SaveChanges();
                        }
                        
                    }
                    
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK);
            }
        }

        // Function to populate MainWindow Datagrid
        private void PopulateDG()
        {
            var ctx = new CourseContext();
            List<Courses> c = ctx.Course.ToList();
            dgMain.ItemsSource = c;
        }

        // Function to Filter Courses
        private void FilterCourses_Closed(object sender, EventArgs e)
        {
            FilterCourses filterCourses = (FilterCourses)sender;

            using (var ctx = new CourseContext())
            {
                var filteredCourses = from c in ctx.Course
                                      select c;

                if (filterCourses.txtSemester.Text != "")
                {
                    filteredCourses = filteredCourses.Where(x => x.Semester == filterCourses.txtSemester.Text);
                }
                if (filterCourses.txtYear.Text != "")
                {
                    int year = Convert.ToInt32(filterCourses.txtYear.Text);
                    filteredCourses = filteredCourses.Where(x => x.Year == year);
                }
                if (filterCourses.txtInsFN.Text != "")
                {
                    var instructor = ctx.Instructor.FirstOrDefault(x => x.FirstName == filterCourses.txtInsFN.Text);
                    filteredCourses = filteredCourses.Where(x => x.Instructor_Id == instructor.Id);
                }
                if (filterCourses.txtInsLN.Text != "")
                {
                    var instructor = ctx.Instructor.FirstOrDefault(x => x.LastName == filterCourses.txtInsLN.Text);
                    filteredCourses = filteredCourses.Where(x => x.Instructor_Id == instructor.Id);
                }
                if (filterCourses.txtDepartment.Text != "")
                {
                    filteredCourses = filteredCourses.Where(x => x.Dept == filterCourses.txtDepartment.Text);
                }
                if (filterCourses.txtNumber.Text != "")
                {
                    int num = Convert.ToInt32(filterCourses.txtNumber.Text);
                    filteredCourses = filteredCourses.Where(x => x.Number == num);
                }

                Debug.WriteLine(filteredCourses);
                dgMain.ItemsSource = filteredCourses.ToList();
                dgMain.Items.Refresh();
            }
        }
    }

    public class Courses
    {
        public int Id { get; set; }
        public string Dept { get; set; }
        public int Number { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string PreReq { get; set; }
        [ForeignKey("Instructors")]
        public int Instructor_Id { get; set; }
        public virtual List<Instructors> Instructors { get; set; }
        public string Status { get; set; }
        public int ClassSize { get; set; }
        public int Enrolled { get; set; }
        public string Semester { get; set; }
        public int Year { get; set; }
        public string Section { get; set; }
        public int Hours { get; set; }
        public string Days { get; set; }
        public string Time { get; set; }
        public string RoomNum { get; set; }
    }

    public class Instructors
    {
        [Key]
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public virtual List<Courses> Courses { get; set; }

        public override string ToString()
        {
            return string.Format("{0} {1}", FirstName, LastName);
        }

        public Instructors()
        {
            Courses = new List<Courses>();
        }
    }

    public class CourseContext : DbContext
    {
        public CourseContext() : base(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sever\Documents\CourseReg2.mdf;Integrated Security=True;Connect Timeout=30") { this.Configuration.LazyLoadingEnabled = false; }
        
        public DbSet<Courses> Course { get; set; }
        public DbSet<Instructors> Instructor { get; set; }

    }
}