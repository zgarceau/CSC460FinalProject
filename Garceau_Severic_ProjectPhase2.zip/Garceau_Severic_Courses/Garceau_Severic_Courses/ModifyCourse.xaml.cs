﻿using System.Windows;

namespace Garceau_Severic_Courses
{
    public partial class ModifyCourse : Window
    {
        public ModifyCourse()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
